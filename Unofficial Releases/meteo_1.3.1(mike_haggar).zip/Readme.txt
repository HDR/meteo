Meteo 1.3.1 English
Translation by Mike_Haggar

As complete translation as I can do at the current time...
There are a couple of error messages that's not translated,
but it's errors that I've not gotten yet...

This has been translated straight from the Japanese version.
Some stuff that were missing is now in place again.
The old partial english translated version was no good.

http://www.gameboy-advance.net/video/
The place to get this translated version.
Read the documentation they got there too.
It'll teach you to use this program.